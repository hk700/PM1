#ifndef SAVINGS_H
#define SAVINGS_H
using namespace std;

#include "account.h"


class Savings : public Account

{
public:

    Savings( double, double );

    double Interest();

private:

    double interestRate;

};

#endif
