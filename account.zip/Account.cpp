
#include <iostream>
using std::cout;
using std::endl;
using namespace std;

#include "account.h"


Account::Account( double initial )
{

    if ( initial >= 0.0 )

        bal = initial;

    else

    {
        cout << "Cannot be negative." << endl;
        bal = 0.0;
    }
}


void Account::credit( double amount )

{
    bal = bal + amount;
}

bool Account::debit( double amount )

{
    if ( amount > bal )

    {
        cout << "Error." << endl;
        return false;
    }

    else

    {
        bal = bal - amount;
        return true;
    }
}




double Account::getBalance()

{
    return bal;
}