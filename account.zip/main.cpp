// Course Number and section: 14:332:254:02
// Lab Instructor: Kazem Cheshmi
// Date Performed: 04/16/2018
// Date Submitted: 04/17/2018
// Submitted by: Hyun Sik Kim, 4794
#include <iostream>
#include <iomanip>
#include "Account.h"
#include "SavingsAccount.h"
using namespace std;
using std::setprecision;
using std::fixed;

int main()
{
    Account account1( 50.0 );
    Savings account2( 25.0, .03 );

    cout << fixed << setprecision( 2 );

    cout << "acc1 balance: $" << account1.getBalance() << endl;
    cout << "acc2 balance: $" << account2.getBalance() << endl;

    cout << "\ndebiting $30.00 from account1." << endl;
    account1.debit( 30.0 );

    cout << "\ndebiting $15.00 from account2." << endl;
    account2.debit( 15.0 );


    cout << "\nacc1 balance: $" << account1.getBalance() << endl;

    cout << "\nacc2 balance: $" << account2.getBalance() << endl;

    cout << "\nCrediting $90.00 to account1." << endl;
    account1.credit( 90.0 );

    cout << "\nCrediting $100.00 to account2." << endl;
    account2.credit( 100.0 );

    cout << "\nacc1 balance: $" << account1.getBalance() << endl;

    cout << "acc2 balance: $" << account2.getBalance() << endl;

    double interestEarned = account2.Interest();

    cout << "\nAdding $" << interestEarned << " interest to account2."

         << endl;
    account2.credit( interestEarned );

    cout << "\nNew account2 balance: $" << account2.getBalance() << endl;

    system("pause");

    return 0;
}