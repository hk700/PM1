#include <iostream>
using namespace std;
#include "SavingsAccount.h"

Savings::Savings( double initial, double rate ): Account( initial )

        {
                interestRate = ( rate < 0.0 ) ? 0.0 : rate;
        }


double Savings::Interest()

{
    return getBalance() * interestRate;
}

