//
// Created by khszz on 5/5/2018.
//

#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <fstream>
#include <iomanip>
#include <string>
#include <stdlib.h>
using namespace std;

#include "bankAccount.h"

bankAccount::bankAccount(double BA) : Account(BA)
{

}

void bankAccount::deposit(double BA)
{
    time_t rawtime;
    time (&rawtime);
    set(BA+get());
    ofstream historyBank("bank_transaction_history.txt", ios::app);
    historyBank <<"\nDeposit" << setw(9) << BA << setw(13) << get() << setw(41)
                << ctime(&rawtime) ;
    ;
}

void bankAccount::withdraw(double BA){
    time_t rawtime;
    time (&rawtime);
    if(BA > get())
        cout << "\nInvalid. "<<endl;
    else
    {
        set( get() - BA);

        ofstream historyBank("bank_transaction_history.txt", ios::app);
        historyBank <<"\nWithdraw" << setw(9) << BA << setw(13) << get() << setw(41)
                    << ctime(&rawtime) ;
        historyBank.close();
    }
    ;
}
void bankAccount::portfolio(){

    string line;
    srand(unsigned (time(NULL)));
    int num = rand()%4 + 1;
    string name = "stock" + to_string(num) + ".txt";
    ifstream file(name, ios::in);


}

// bankAccount Menu
void bankAccount::menu() {
    bool choice = true;
    int selection;

    while (choice) {
        cout << "\nPlease select an option" << endl
             << "\t1. View account balance" << endl
             << "\t2. Deposit money" << endl
             << "\t3. Withdraw money" << endl
             << "\t4. Display transaction history" << endl
             << "\t5. Return to previous menu" << endl;

        cout << "\tYour selection: ";


        while(!(cin>>selection)){
            cout << "\nPlease select an option" << endl
                 << "\t1. View account balance" << endl
                 << "\t2. Deposit money" << endl
                 << "\t3. Withdraw money" << endl
                 << "\t4. Display transaction history" << endl
                 << "\t5. Return to previous menu" << endl;

            cout << "\tYour selection: ";
            cin.clear();
            cin.ignore(100, '\n');
        }


        switch(selection) {
            case 1:
                cout << "\nCash balance = " << get() << endl;
                break;
            case 2: {
                double amount;
                cout << "\nEnter Amount to deposit: ";
                cin >> amount;
                deposit(amount);
                break;
            }
            case 3: {
                double amount;
                cout << "\nEnter Amount to withdrawal: ";
                cin >> amount;
                withdraw(amount);
                break;
            }
            case 4:{
                string out;
                ifstream history("bank_transaction_history.txt");

                while(getline(history,out)){

                    cout << endl<< out << endl;
                }
                break;
            }
            case 5:
                cout << "\nReturning to previous menu. \n\n" ;
                cin.clear();
                cin.ignore(100, '\n');
                choice = false;
                break;
            default:

                cout << "\nInvalid: \n\n" << endl;

                break;
        }
    }
}