//
// Created by khszz on 5/5/2018.
//

#include <iostream>
#include <stdio.h>
#include <unistd.h> // for sleep
#include <fstream>
#include<vector>
#include<iomanip>
#include <ctime>


#include "stockAccount.h"
stockAccount::stockAccount(double BA) : Account(BA) {

}


void stockAccount::stockPrice(string symbol) {


    string line;
    srand(unsigned (time(NULL)));
    int num = rand()%4 + 1;
    string name = "stock" + to_string(num) + ".txt";
    ifstream file(name, ios::in);
    int count = 0;
    time_t rawtime;
    time (&rawtime);

    while(!file.eof()){

        getline(file,line);

        if(!line.find(symbol))
        {
            line.back() = '\t';
            cout << line << ctime(&rawtime) ;
            break;
        }


        count++; }
    if(file.eof()){
        cout << "\n The Symbol you enter was not found. \n";
    }

    file.close();
    ;
}

void stockAccount::buyStock(string symbol, int numShare, double price) {

    string line;
    srand(unsigned (time(NULL)));
    int num = rand()%4 + 1;
    string name = "stock" + to_string(num) + ".txt";
    ifstream file(name, ios::in);
    int count = 0;

    while(!file.eof()){

        getline(file,line);

        if(!line.find(symbol))
        {
            break;
        }


        count++; }
    if(file.eof()){
        cout << "\n The Symbol you enter was not found. \n";
    }
    else{

        if (get() < numShare*price)
            cout << " Insufficient cash baance. ";
        if (get() >= numShare*price){
            set(get()-numShare*price);

            ofstream historyfile("stock_transaction_history.txt", ios::app);
            historyfile << "\n\nBUY          "
                        << line.substr(0,20) << setw(15)<< price << setw(15)<< numShare;

            historyfile.close();
            file.close();
            ;
        }
    }
}

void stockAccount::sellStock(string symbol, int numShare, double price) {


    string line;
    srand(unsigned (time(NULL)));
    int num = rand()%4 + 1;
    string name = "stock" + to_string(num) + ".txt";
    ifstream file(name, ios::in);
    int count = 0;


    while(!file.eof()){

        getline(file,line);

        if(!line.find(symbol))
        {
            break;
        }


        count++; }

    if(file.eof()){
        cout << "\n The Symbol you enter was not found. \n";
    }
    else{
        set(get()+numShare*price);

        ofstream historyfile("stock_transaction_history.txt", ios::app);
        historyfile << "\n\nSELL          "
                    << line.substr(0,20) << setw(15)<< price << setw(15)<< numShare;

        historyfile.close();
        file.close();

        ;
    }
}

void stockAccount::portfolio() {

    string line;
    srand(unsigned (time(NULL)));
    int num = rand()%4 + 1;
    string name = "stock" + to_string(num) + ".txt";
    ifstream file(name, ios::in);


}

void stockAccount::menu() {
    bool flag = true;
    int choice = 0;


    while (flag) {
        cout << "\nPlease select an option" << endl
             << "\t1. Display current price for a stock symbol" << endl
             << "\t2. Buy stock" << endl
             << "\t3. Sell stock" << endl
             << "\t4. Display current portfolio" << endl
             << "\t5. Display transaction history" << endl
             << "\t6. Return to previous menu" << endl;

        cout << "\tYour selection: ";

        while(!(cin>>choice)){
            cout << "\nPlease select an option" << endl
                 << "\t1. Display current price for a stock symbol" << endl
                 << "\t2. Buy stock" << endl
                 << "\t3. Sell stock" << endl
                 << "\t4. Display current portfolio" << endl
                 << "\t5. Display transaction history" << endl
                 << "\t6. Return to previous menu" << endl;

            cout << "\tYour selection: ";
            cin.clear();
            cin.ignore(100, '\n');
        }


        switch(choice) {
            case 1: {
                string symbol;
                cout << "Enter stock symbol for checking price: ";
                cin >> symbol;
                stockPrice(symbol);
                break;
            }
            case 2: {
                string symbol; int shares; double amount;
                cout << "Enter Buy Options (Symbol Shares Price): ";
                cin >> symbol >> shares >> amount;
                buyStock(symbol, shares, amount);
                break;
            }
            case 3: {
                string symbol; int shares; double amount;
                cout << "Enter Sell Options (Symbol Shares Price): ";
                cin >> symbol >> shares >> amount;
                sellStock(symbol, shares, amount);
                break;
            }
            case 4:
                cout << "\nCash balance = " << get() << endl;
                break;
            case 5:{
                string out;
                ifstream history("stock_transaction_history.txt");

                while(getline(history,out)){

                    cout << endl<< out << endl;
                }

                break;
            }
            case 6:
                cout << "\nReturning to previous menu. \n\n" ;
                cin.clear();
                cin.ignore(100, '\n');
                flag = false;
                break;
            default:
                cout << "\nIncorrect selection. Try again: \n\n" << endl;
                break;

        }
    }
}