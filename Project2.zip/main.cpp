//main.cpp
# include "Account.h"
# include "stockAccount.h"
# include "bankAccount.h"


# include <iostream>
# include <string>
#include <unistd.h>
#include<fstream>

using namespace std;

int main() {


    stockAccount a;
    bankAccount b;

    bool select = true;
    int selection = 0;
    char check[256];
    string line;
    while (select) {

        cout << "Please select an account to access" << endl
             << "\t1. Stock Portfolio Account" << endl
             << "\t2. Bank Account" << endl
             << "\t3. Exit" << endl
             << "\tYour selection: ";

        cin.getline(check, 256);

        selection = atoi(check);

        switch (selection) {
            case 1:
                cout << "\n\tPortfilo accont." << endl;
                a.menu();
                break;
            case 2:
                cout << "\n\tBank account." << endl;
                b.menu();
                break;
            case 3:
                cout << "\n\tEXITING" << endl;
                select = false;
                break;
            default:
                cout << "\n\tINVALID." << endl;
                break;
        }
    }




    ofstream historystock("stock_transaction_history.txt");
    historystock << "Action      Symbol    Company                 PRICE             Shares";
    historystock.close();

    ofstream historybank("bank_transaction_history.txt");
    historybank << "Action         Amount   Cash Balance          Date&Time";
    historybank.close();


    return 0;
}