//
// Created by khszz on 5/5/2018.
//

#ifndef PROJECT22_ACCOUNT_H
#define PROJECT22_ACCOUNT_H
#include <iostream>
#include <stdio.h>

using namespace std;

class Account {

public:

    Account(double bal = 10000.0);

    double get() const;

    void set(double);

private:

    double Balance;

};

#endif //PROJECT22_ACCOUNT_H
