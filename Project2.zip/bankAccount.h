//
// Created by khszz on 5/5/2018.
//

#ifndef PROJECT22_BANKACCOUNT_H
#define PROJECT22_BANKACCOUNT_H

#include <iostream>
#include <stdio.h>
#include "Account.h"


using namespace std;

class bankAccount: public Account {

public:

    bankAccount(double BA = 10000.0);
    void deposit(double);
    void withdraw(double);
    void portfolio();
    void menu();


};

#endif //PROJECT22_BANKACCOUNT_H
