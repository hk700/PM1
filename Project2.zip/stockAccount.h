//
// Created by khszz on 5/5/2018.
//

#ifndef PROJECT22_STOCKACCOUNT_H
#define PROJECT22_STOCKACCOUNT_H

#include <iostream>
#include <stdio.h>
#include "Account.h"


using namespace std;

class stockAccount: public Account {

public:

    stockAccount(double BA = 10000.0);
    void stockPrice(string);
    void buyStock(string, int, double);
    void sellStock(string, int, double);
    void portfolio();
    void menu();


};
#endif //PROJECT22_STOCKACCOUNT_H
