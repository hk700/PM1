//
// Created by khszz on 5/5/2018.
//
#include <iostream>
#include <fstream>

#include "Account.h"

using namespace std;


Account::Account(double bal)
{
    Balance = bal;

}

double Account::get() const
{

    return Balance;

}

void Account::set(double amount)
{
    Balance = amount;
}


